create table if not exists libros(
    ISBN varchar primary key,
    titulo varchar not null
);